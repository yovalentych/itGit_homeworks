module.exports = function (obj1, obj2) {
  return Object.is(obj1, obj2);
};
