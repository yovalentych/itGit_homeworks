# itgid.info - python 2023

# Напишите функцию f12, которая принимает аргумент - list, и возвращает индекс максимального значения из list. Решите с помощью цикла.

# write your code under this line

def f12 (f) :
    pass


b = [2, 3, 11, 5, 6, 9, 12, -4]
result = f12(b)
print (b)
