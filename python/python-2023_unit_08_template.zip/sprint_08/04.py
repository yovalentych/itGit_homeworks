# itgid.info - python 2023

# Напишите функцию f04, которая принимает аргумент - list, и возвращает cумму четных элементов данного list. Решите с помощью цикла.

# write your code under this line

def f04 (f) :
    pass


b = [1, -2, 4, 5, 2, 7, -11]
result = f04(b)
print (b)
