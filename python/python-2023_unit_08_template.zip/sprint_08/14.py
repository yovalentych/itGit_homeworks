# itgid.info - python 2023

# Напишите функцию f14, которая принимает аргумент - list, и возвращает True если все элементы list - больше нуля и False в противном случае. Решите с помощью цикла.

# write your code under this line

def f14 (f) :
    pass


b = [22, 33, 44, -55, 66]
result = f14(b)
print (b)
