# itgid.info - python 2023

# Напишите функцию f08, которая принимает аргумент - list, и возвращает максимальное значение из list. Решите с помощью цикла.

# write your code under this line

def f08 (f) :
    pass


b = [8, 2, -5, 11, 2, 1, 15, 3]
result = f08(b)
print (b)
