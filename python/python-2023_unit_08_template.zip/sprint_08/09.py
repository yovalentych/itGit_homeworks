# itgid.info - python 2023

# Напишите функцию f09, которая принимает аргумент - list, и возвращает минимальное значение из list. Решите с помощью цикла.

# write your code under this line

def f09 (f) :
    pass


b = [8, 3, 5, 11, 2, 1, 15, 7]
result = f09(b)
print (b)
