# itgid.info - python 2023

# Напишите функцию f02, которая принимает аргумент - list, и возвращает произведение его элементов. Решите с помощью цикла.

# write your code under this line

def f02 (f) :
    pass


b = [1, 2, 4, 5, 2]
result = f02(b)
print (b)
