# itgid.info - python 2023

# Создайте list, состоящий из 3 элементов. Первый - целое число от 1000 до 2000, второе - строка длиной 4 символа, и третье - boolean False. Имя list - m1. Выведите list в консоль.

# write your code under this line

