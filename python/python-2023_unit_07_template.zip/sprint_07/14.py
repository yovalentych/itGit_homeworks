# itgid.info - python 2023

# Напишите функцию f14, которая получает list и индекс. Функция удаляет запись с индексом index из list. Возвращает list.

# write your code under this line
def f14 (ct, index) :
    pass


list1 = ['a', 'b', 'c', 'd', 'e']

result = f14(list1, 2)
print(result)