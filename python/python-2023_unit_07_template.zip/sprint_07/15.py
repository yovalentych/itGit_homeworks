# itgid.info - python 2023

# Напишите функцию f15, которая получает list и проверяет его длину (len). Если в list больше 5 элементов - очищает list. Возвращает list. 

# write your code under this line
def f15 (ct) :
    pass


list1 = ['a', 'b', 'c', 'd', 'e']

result = f15(list1)
print(result)