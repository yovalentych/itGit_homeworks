# itgid.info - python 2023

# Напишите функцию f13, которая получает list1 и list2 и возвращает list1 расширенный элементами list2.

# write your code under this line
def f13 (l1, l2) :
    pass


list1 = ['a', 'b']
list2 = [11, 22]

result = f13(list1, list2)
print(result)