# itgid.info

# Task 08
# Напишите функцию f08 которая получает два tuple и возвращает их объединение.

def f08(t1, t2) :
    pass


tpl_1 = (100, 105, 110)
tpl_2 = (555, 666, 777)

res = f08(tpl_1, tpl_2)

print(res)