# itgid.info

# Task 12
# Напишите функцию f12, которая получает tuple и возвращает сумму его элементов.

def f12(t1) :
    pass


tpl = (100, 105, 110)

res = f12(tpl)

print(res)