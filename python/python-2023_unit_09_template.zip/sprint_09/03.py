# itgid.info

# Task 03
# Напишите функцию f03, получает list как аргумент, создает на его основе tuple и возвращает его.

def f03(m) :
    pass


lst = ["apple", "banana", "cherry"]
print(f03(lst))