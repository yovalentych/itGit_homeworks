# itgid.info

# Task 05
# Напишите функцию f05 которая получает tuple, и создает на его основе list. Возвращает созданный list.

def f05(t) :
    pass


tpl = (100, 105, 110)
res = f05(tpl)
print(res)
print(type(res))