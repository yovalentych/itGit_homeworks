# itgid.info

# Task 01
# Напишите функцию f01, которая создает и возвращает tuple содержащий элементы: 'python', 3.11, 'tuples', 42

def f01() :
    pass

print(f01())