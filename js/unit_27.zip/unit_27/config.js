const URL = 'https://api.itgid.info';
const APIKEY = '3Ukls16nARnda6m9';

// никаких других изменений, добавлений
// оптимизаций - в файл config не вносим!!!
