const URL = 'https://api.itgid.info';
const APIKEY = 'SqnZ1f7CJD5TTViT';

// никаких других изменений, добавлений
// оптимизаций - в файл config не вносим!!!
