const URL = 'https://api.itgid.info';
const APIKEY = 'LIeRSB1cafxGtZNh';

// никаких других изменений, добавлений
// оптимизаций - в файл config не вносим!!!
